# README

## Variants
There are four versions in this repository (on different branches):
- a5_english
- a5_german
- a4_english
- a4_german

The default branch is a5_english as it is the most common option in our workgroup.

## Cover
For the a5 versions, there are cover pages to print the cover of the thesis.